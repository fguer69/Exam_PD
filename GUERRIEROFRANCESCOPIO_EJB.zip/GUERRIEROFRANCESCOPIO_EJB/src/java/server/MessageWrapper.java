/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package server;

import java.io.Serializable;

/**
 *
 * @author fguer
 */
public class MessageWrapper implements Serializable{
  private int id;
    private String titolo;
    private String descrizione;
    private String data;
    private String ora;
    private String struttura;
    private float costo;
    private String categoria;

    public MessageWrapper (){}

    public MessageWrapper ( int id,String titolo, String descrizione, String data, String ora, String struttura, float costo, String categoria){
        this.id=id;
        this.titolo=titolo;
        this.descrizione=descrizione;
        this.data=data;
        this.ora=ora;
        this.struttura=struttura;
        this.costo=costo;
        this.categoria=categoria;
    }

    public int getId() {
        return id;
    }

    public String getTitolo() {
        return titolo;
    }

    public String getDescrizione() {
        return descrizione;
    }

    public String getData() {
        return data;
    }

    public String getOra() {
        return ora;
    }

    public String getStruttura() {
        return struttura;
    }

    public float getCosto() {
        return costo;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setTitolo(String titolo) {
        this.titolo = titolo;
    }

    public void setDescrizione(String descrizione) {
        this.descrizione = descrizione;
    }

    public void setData(String data) {
        this.data = data;
    }

    public void setOra(String ora) {
        this.ora = ora;
    }

    public void setStruttura(String struttura) {
        this.struttura = struttura;
    }

    public void setCosto(float costo) {
        this.costo = costo;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    @Override
    public String toString() {
        return "MessageWrapper{" + "id=" + id + ", titolo=" + titolo + ", descrizione=" + descrizione + ", data=" + data + ", ora=" + ora + ", struttura=" + struttura + ", costo=" + costo + ", categoria=" + categoria + '}';
    }
}