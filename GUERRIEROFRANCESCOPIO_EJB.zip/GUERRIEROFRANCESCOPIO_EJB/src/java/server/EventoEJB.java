/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package server;

import java.util.List;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.interceptor.Interceptors;
import javax.jws.WebService;
import javax.persistence.EntityManager;

/**
 *
 * @author fguer
 */
@Stateless
@LocalBean
@WebService
public class EventoEJB implements EventoEJBRemote{
    @Inject
    private EntityManager em;
    
    
    public void addEvento(Evento e) {
        em.persist(e);
    }


    
    public void updateEvento(Evento e) {
        em.merge(e);
    }

    
    public void removeEvento(Evento e) {
       em.remove(em.merge(e));
    }

    @Override
    public Evento trovaId(int id) {
        Evento q = em.createNamedQuery(Evento.ID, Evento.class).setParameter("id", id).getSingleResult();
        return q;
    }

    @Override
    public List<Evento> trovaData(String data) {
        List<Evento> q = em.createNamedQuery(Evento.DATA, Evento.class).setParameter("data", data).getResultList();
        return q;
    }

    @Override
    public List<Evento> trovaCategoria(String categoria) {
        List<Evento> q = em.createNamedQuery(Evento.CATEGORIA, Evento.class).setParameter("categoria", categoria).getResultList();
        return q;
    }

    //Corretta annotazione per gli interceptors
    @Interceptors({CheckStrutturaInterceptor.class,CountInterceptor.class})
    public List<Evento> trovaStruttura(String struttura) {
        List<Evento> q = em.createNamedQuery(Evento.STRUTTURA, Evento.class).setParameter("struttura", struttura).getResultList();
        return q;
    }

    //Cambiare implementazione simile a id
    public Evento trovaTitolo(String titolo) {
        Evento q = em.createNamedQuery(Evento.TITOLO, Evento.class).setParameter("titolo", titolo).getSingleResult();
        return q;
    }

    
   @Interceptors({CheckStrutturaInterceptor.class,CountInterceptor.class})
    @Override
    public List<Evento> trovaStrutturaData(String struttura, String data) {
        List<Evento> q = em.createNamedQuery(Evento.STRUTTURA_DATA, Evento.class).setParameter("struttura", struttura).setParameter("data", data).getResultList();
        return q;
    }
    
    @Override
    public List<Evento> trovaTutti() {  
        List<Evento> q = em.createNamedQuery(Evento.TUTTI, Evento.class).getResultList();
        return q;
    }
}
