/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package server;

import javax.enterprise.event.Observes;

/**
 *
 * @author fguer
 */
public class UpdateNotification {
    public void notify(@Observes  Evento e) {
        System.out.println("INFO: Eventi multipli " + e.toString());
    }    
}
