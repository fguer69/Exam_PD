/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package server;

import javax.interceptor.AroundInvoke;
import javax.interceptor.Interceptor;
import javax.interceptor.InvocationContext;

/**
 *
 * @author fguer
 */
@Interceptor
@CounterStruttura
public class CountInterceptor {
    private int count = 0;
    private int countSi = 0; 
    private int countNo = 0;
    
    @AroundInvoke
    public Object count(InvocationContext ic) throws Exception{

   String struttura = (String)ic.getParameters()[0];

        if(struttura.equals("Giggetto")){
        countSi++;
        }else{
             countNo++;
        }
         count= countSi - countNo;   
         if(count> 20){
             System.out.println("Forza andiamo anche da giggietto!");
             count = 0;
         }
         
    return ic.proceed();
    }
}

