/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package server;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.annotation.sql.DataSourceDefinition;
import javax.ejb.Singleton;
import javax.ejb.Startup;
import javax.inject.Inject;

/**
 *
 * @author fguer
 */
@Singleton
@Startup
@DataSourceDefinition(
        className = "org.apache.derby.jdbc.EmbeddedDataSource",
        name = "java:global/jdbc/EsameDS",
        user = "app",
        password = "app",
        databaseName = "EsameDB"
)
public class DataBasePopulator{  
    @Inject
    EventoEJB ejb;
   
    Evento e, e1, e2;
        
    @PostConstruct
    public void populateDB() {
       e = new Evento( 1,"festa di Natale 2023", "Quest'anno la festa di Natale si terrà da Giggetto. Vi aspettiamo numerosi!", 
                "25/12/2023", " 14:00", "Giggetto", 30.0f, "JAZZ");
        e1 = new Evento( 2,"festa di Pasqua 2024", "Quest'anno la festa di Pasqua si terrà da Francesco. Vi aspettiamo numerosi!", 
                "01/04/2021", " 14:00", "Francesco", 50.0f, "POP");
        e2 = new Evento( 3,"festa della Liberazione 2024", "Quest'anno la festa della Liberazione si terrà da Giggetto. Vi aspettiamo numerosi!", 
                "25/04/2024", " 14:00", "Giggetto", 450.0f, "POP");
        ejb.addEvento(e);
        ejb.addEvento(e1);
        ejb.addEvento(e2);
    }

    @PreDestroy
    public void clearDB() {
        ejb.removeEvento(e);
        ejb.removeEvento(e1);
        ejb.removeEvento(e2);
    }

}
