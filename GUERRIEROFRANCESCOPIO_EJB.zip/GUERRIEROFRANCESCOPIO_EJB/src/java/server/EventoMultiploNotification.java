/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package server;

import java.util.List;
import javax.enterprise.event.Observes;
import javax.inject.Inject;

/**
 *
 * @author fguer
 */
public class EventoMultiploNotification {
    @Inject
    private EventoEJB eventoEJB;

    public void notify(@Observes @EventoMultiplo Evento e) {
        System.out.println("LISTA EVENTI CON STESSA STRUTTURA");
        List<Evento> listaEvento = eventoEJB.trovaTutti();
        for (Evento e1 : listaEvento) {
            if (e1.getStruttura().equals(e.getStruttura()) && e1.getId() != (e.getId())) {
                   System.out.println( e1.toString());
            }
        }

    }
}