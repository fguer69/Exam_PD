/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package server;

import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ejb.MessageDriven;
import javax.enterprise.event.Event;
import javax.inject.Inject;
import javax.jms.JMSException;

import javax.jms.Message;
import javax.jms.MessageListener;

/**
 *
 * @author fguer
 */
@MessageDriven(mappedName="jms/javaee7/Topic")
public class MDB implements MessageListener{
    @Inject
    private EventoEJB eventoEJB;
    @Inject 
    Event<Evento> event;
    @Inject @EventoMultiplo
    Event<Evento> eventoMultiplo;

    private int controllo = 0;
    @Override
    public void onMessage(Message message) {
        
        try{
            MessageWrapper msgContent = message.getBody(MessageWrapper.class);

            int id = msgContent.getId();
            String titolo = msgContent.getTitolo();
            String descrizione = msgContent.getDescrizione();
            String data = msgContent.getData();
            String ora = msgContent.getOra();
            String struttura = msgContent.getStruttura();
            float costo = msgContent.getCosto();
            String categoria = msgContent.getCategoria();
            
            //Commento il codice per errato funzionamento
            //Creo una nuova istanza dell'entity con i valorei appena presi e poi lo aggiungo
            Evento e = new Evento(id,titolo,descrizione,data,ora,struttura,costo,categoria);
            eventoEJB.addEvento(e);
            
            
            List <Evento> list = eventoEJB.trovaTutti();
            Evento e1 = eventoEJB.trovaId(id);
            
            for(Evento e2 : list){
                if(e1.getStruttura().equals(e2.getStruttura())){
                    controllo++;
                }
            }
      
            if(controllo >=2){
                event.fire(e1);
                eventoMultiplo.fire(e1);
            }

            } catch(JMSException ex){
            
            Logger.getLogger(MDB.class.getName()).log(Level.SEVERE, null, ex);
            }
    }
}


   //        Song s = songEJB.trovaId(id);
//        s.setTitolo(titolo);
//        s.setDescrizione(descrizione );
//        s.setData(data );
//        s.setOra(ora );
//        s.setStruttura(struttura );
//        s.setCosto(costo );
//        s.setCategoria(categoria );
//        event.fire(s);
//        if(s.getStruttura().equals("Francesco") & msgContent.getStruttura().equals("Francesco")){
//        List<Song> list = songEJB.trovaTutti();
//        System.out.println(msgContent);
//       }
//        eventoMultiplo.fire(s);
        