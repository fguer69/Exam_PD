/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package server;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author fguer
 */
@Entity
@XmlRootElement
@NamedQueries({
    @NamedQuery(name=server.Evento.ID, query="SELECT s FROM  Evento s WHERE s.id = :id"),
    @NamedQuery(name=server.Evento.DATA, query="SELECT s FROM Evento s WHERE s.data=:data"),
    @NamedQuery(name=server.Evento.CATEGORIA, query="SELECT s FROM  Evento s WHERE s.categoria = :categoria "),
    @NamedQuery(name=server.Evento.STRUTTURA , query="SELECT s FROM  Evento s WHERE s.struttura= :struttura"),
    @NamedQuery(name=server.Evento.TITOLO, query="SELECT s FROM  Evento s WHERE s.titolo= :titolo"),
    @NamedQuery(name=server.Evento.STRUTTURA_DATA, query="SELECT s FROM  Evento s WHERE s.struttura = :struttura AND s.data = :data"),
    @NamedQuery(name=server.Evento.TUTTI, query="SELECT s FROM  Evento s "),
})

//Cambio nome classe per motivi di compilazione
public class Evento implements Serializable{
    //correzioni sintattiche stati -> static 
    //aggiunta query per ricerca di una strutture in una precista data
    public static final String ID = " trovaId";
    public static final String DATA = " trovaData";
    public static final String CATEGORIA = " trovaCategoria";
    public static final String STRUTTURA = " trovaStruttura";
    public static final String TITOLO= " trovaTitolo";
    public static final String STRUTTURA_DATA= " trovaStrutturaData";
    public static final String TUTTI= " trovaTutti";
    
    @Id
    private int id;
   @Column(unique=true)
    private String titolo;
    private String descrizione;
    private String data;
    private String ora;
    private String struttura;
    private float costo;
    private String categoria;

    public Evento() {
    }

    public Evento(int id, String titolo, String descrizione, String data, String ora, String struttura, float costo, String categoria) {
        this.id = id;
        this.titolo = titolo;
        this.descrizione = descrizione;
        this.data = data;
        this.ora = ora;
        this.struttura = struttura;
        this.costo = costo;
        this.categoria = categoria;
    }

    public int getId() {
        return id;
    }

    public String getTitolo() {
        return titolo;
    }

    public String getDescrizione() {
        return descrizione;
    }

    public String getData() {
        return data;
    }

    public String getOra() {
        return ora;
    }

    public String getStruttura() {
        return struttura;
    }

    public float getCosto() {
        return costo;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setTitolo(String titolo) {
        this.titolo = titolo;
    }

    public void setDescrizione(String descrizione) {
        this.descrizione = descrizione;
    }

    public void setData(String data) {
        this.data = data;
    }

    public void setOra(String ora) {
        this.ora = ora;
    }

    public void setStruttura(String struttura) {
        this.struttura = struttura;
    }

    public void setCosto(float costo) {
        this.costo = costo;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    @Override
    public String toString() {
        return "Song{" + "id=" + id + ", titolo=" + titolo + ", descrizione=" + descrizione + ", data=" + data + ", ora=" + ora + ", struttura=" + struttura + ", costo=" + costo + ", categoria=" + categoria + '}';
    }
    
    
}
