/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package server;

import java.util.List;
import javax.ejb.Remote;

/**
 *
 * @author fguer
 */
@Remote
public interface EventoEJBRemote {
    
    public void addEvento(Evento e);
    public void updateEvento(Evento e);
    public void removeEvento(Evento e);

//QUERY

    Evento trovaId(int id);
    List <Evento>trovaData(String data);
    List <Evento>trovaCategoria(String categoria);
    List <Evento>trovaStruttura(String struttura);
    //Cambiare query non deve essere un list
    Evento trovaTitolo(String titolo);
    List <Evento>trovaStrutturaData(String struttura, String data);
    List <Evento> trovaTutti();
    
}
