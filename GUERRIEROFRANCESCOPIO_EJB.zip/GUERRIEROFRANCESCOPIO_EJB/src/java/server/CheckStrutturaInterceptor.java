/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package server;

import javax.interceptor.AroundInvoke;
import javax.interceptor.Interceptor;
import javax.interceptor.InvocationContext;

/**
 *
 * @author fguer
 */
@Interceptor
@CheckStruttura
public class CheckStrutturaInterceptor {
     @AroundInvoke
    public Object check (InvocationContext ic) throws Exception{

        String struttura = (String)ic.getParameters()[0];

           if(struttura.equals("Giggetto")){
             System.out.println("Tutti da giggetto");
           }

        return ic.proceed();
        }
}
