/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package guerrierofrancescopi_ws;

import java.util.List;
import java.util.Scanner;
import javax.naming.NamingException;
import server.Evento;
import server.EventoEJB;
import server.EventoEJBService;

/**
 *
 * @author fguer
 */
public class GUERRIEROFRANCESCOPI_WS {

    /**
     * @param args the command line arguments
     */
   
   public static void main(String[] args) throws NamingException{

   EventoEJBService service = new EventoEJBService();

   EventoEJB port = service.getEventoEJBPort();



        System.out.println("Stampo tutti gli eventi ");
        List<Evento>list = port.trovaTutti();
        for(Evento s : list){
        System.out.println(s);
        }
//CAMBIO FORMA 
        System.out.println("Inserire il titolo del evento da modificare:");
        Scanner scan = new Scanner(System.in);
        String titolo = scan.nextLine();
        Evento s = port.trovaTitolo(titolo);
        System.out.println("id:" + s.getId() + ", Titolo:" + s.getTitolo() + ", Categoria:" + s.getCategoria());
        System.out.println("Inserire categoria da modificare:");
        Scanner scanner = new Scanner(System.in);
        String categoria = scanner.nextLine();
        s.setCategoria(categoria);
        port.updateEvento(s);
        System.out.println("id:" + s.getId() + ", Titolo:" + s.getTitolo() + ", Categoria:" + s.getCategoria());
        
//        System.out.println("Inserisci la nuova categotia di un evento:");
//        Scanner scan = new Scanner(System.in);
//        String categoria = scan.nextLine();
//        Song s = port.trovaTitolo("festa di Natale 2023");
//        s.setCategoria(categotia);
//        port.updateSong(s);

   }
}


    
