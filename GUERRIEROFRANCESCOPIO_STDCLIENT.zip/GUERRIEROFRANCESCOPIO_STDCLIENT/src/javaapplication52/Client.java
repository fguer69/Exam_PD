/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package javaapplication52;

import server.Evento;
import server.EventoEJBRemote;
import java.util.List;
import java.util.Scanner;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

/**
 *
 * @author fguer
 */
public class Client{

public static EventoEJBRemote songEJB;

   public static void main(String[] args) throws NamingException{
   Context ctx= new InitialContext();
   songEJB = (EventoEJBRemote) ctx.lookup("java:global/GUERRIEROFRANCESCOPIO_EJB/EventoEJB!server.EventoEJBRemote");

        System.out.println("Stampo tutti gli eventi per Data");
        List<Evento> list = songEJB.trovaData("25/12/2023");
        for(Evento s : list){
        System.out.println(s.toString());
       }
        

        System.out.println("inserisci categoria");
        Scanner scan = new Scanner(System.in);
        String categoria = scan.nextLine();
        System.out.println("Tutte gli eventi per una certa Categoria musicale:" + categoria);
        List<Evento>lista = songEJB.trovaCategoria(categoria);
        for(Evento s1 : lista){
        System.out.println(s1);
        }

        System.out.println("inserisci struttura");
        Scanner scann = new Scanner(System.in);
        String struttura= scann.nextLine();
        System.out.println("Tutte gli eventi che avranno luogo da: " + struttura);
        List<Evento>listone = songEJB.trovaStruttura(struttura);
        for(Evento s2 : listone){
        System.out.println(s2);
        }

        //CAMBIO IL NOME DELLA VARIABILE String struttura -> struttura1
        //AGGIUNGO LA VARIABILE DATA PER L'UTILIZZO DELLA QUERY trovaStrutturaData AGGIUNTA 
        System.out.println("inserisci struttura");
        Scanner scanne = new Scanner(System.in);
        String struttura1= scanne.nextLine();
        System.out.println("inserisci data");
        Scanner scanner = new Scanner(System.in);
        String data= scanner.nextLine();
        System.out.println("Tutte gli eventi che avranno luogo da: " + struttura  +" il: " + data);
        List<Evento>liston = songEJB.trovaStrutturaData(struttura, data);
        for(Evento s3 : liston){
        System.out.println(s3);

        }
    }
    
}
